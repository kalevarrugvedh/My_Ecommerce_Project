export class Customer {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  mobile: number;
}
